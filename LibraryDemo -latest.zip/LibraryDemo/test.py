import arsac

print(arsac.hello())
print(arsac.my_function())