from setuptools import setup, find_packages

VERSION = '0.0.13'
DESCRIPTION = 'Streaming video data via networks'

# Setting up
setup(
    name="arsac",
    version=VERSION,
    author="NeuralNine (Florian Dedov)",
    author_email="<mail@neuralnine.com>",
    description=DESCRIPTION,
    packages=find_packages(include=['arsac', 'arsac.*']),
    install_requires=['pandas'],
    keywords=['python','helloworld'],
    entry_points={
        'console_scripts': [
            'module1=arsac.myscript.module1.main:main',
        ],
    },
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
    ],
    package_data={
        'arsac.myscript.module1': ['config.properties'],
    },
    python_requires='>=3.9',
    include_package_data=True,
)