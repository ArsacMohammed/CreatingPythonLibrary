import os
import configparser

def read_properties():
    properties = {}
    project_config = configparser.ConfigParser()
    properties_path = os.path.join('config.properties')
    project_config.read(properties_path)

    library_config = configparser.ConfigParser()
    properties_path1 = os.path.join(os.path.dirname(__file__), 'config.properties')
    library_config.read(properties_path1)

    for section in project_config.sections():
        properties = dict(project_config.items(section))

    keys_properties = properties.keys()
    for section in library_config.sections():
        for key, value in library_config.items(section):
            if key not in keys_properties:
                properties[key] = value


    return properties


def main_function():
    print(read_properties())


if __name__ == "__main__":
    main_function()
