from .main import read_properties
def hello():
    print("Hello World")
    return ""



def my_function():
    properties = read_properties()
    property1 = properties.get('property1', 'default_value')
    property2 = properties.get('property2', 'default_value')
    print(f"Property1: {property1}")
    print(f"Property2: {property2}")
    return ""







