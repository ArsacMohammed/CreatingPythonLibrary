from .myscript.module1 import *

